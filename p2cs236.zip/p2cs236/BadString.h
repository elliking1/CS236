#ifndef P2CS236_BADSTRING_H
#define P2CS236_BADSTRING_H
#pragma once
#include "Automaton.h"

class BadString : public Automaton
{
public:
    BadString(TokenType tokenType) { this->type = tokenType; };
    //       ~BadString();
    int Start(const std::string& input);
};
#endif