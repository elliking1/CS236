#ifndef P2CS236_PLAINPARAMETER_H
#define P2CS236_PLAINPARAMETER_H
#pragma once
#include "Parameter.h"

class PlainParameter : public Parameter {

public:

    PlainParameter(std::string parameter){
        this->parameter = parameter;
    };

    std::string toString() {
        return parameter;
    }
};
#endif //P2CS236_PLAINPARAMETER_H
