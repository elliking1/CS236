#ifndef P2CS236_COMMENTAUTOMATON_H
#define P2CS236_COMMENTAUTOMATON_H
#pragma once
#include "Automaton.h"

class CommentAutomaton : public Automaton
{
public:
    CommentAutomaton(TokenType tokenType) { this->type = tokenType; };
//        ~CommentAutomaton();
    int Start(const std::string& input);

};
#endif