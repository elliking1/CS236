#ifndef P2CS236_PARAMETER_H
#define P2CS236_PARAMETER_H
#pragma once
#include <string>

class Parameter {
protected:
    std::string parameter;

public:

    Parameter() {};

    virtual ~Parameter() = default;

    virtual std::string toString() {return " ";};

};
#endif //P2CS236_PARAMETER_H
