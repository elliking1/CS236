#ifndef P2CS236_BADCOMMENT_H
#define P2CS236_BADCOMMENT_H
#pragma once
#include "Automaton.h"

class BadComment : public Automaton
{
public:
    BadComment(TokenType tokenType) { this->type = tokenType; };
    //  ~BadComment();
    int Start(const std::string& input);

};
#endif