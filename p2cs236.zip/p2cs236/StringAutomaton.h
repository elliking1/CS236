#ifndef P2CS236_STRINGAUTOMATON_H
#define P2CS236_STRINGAUTOMATON_H

#pragma once
#include "Automaton.h"

class StringAutomaton : public Automaton
{
public:
    StringAutomaton(TokenType tokenType) { this->type = tokenType; };
    //     ~StringAutomaton();
    int Start(const std::string& input);
};
#endif